import puppeteer from 'puppeteer-core';
import chromium from '@sparticuz/chromium'; // Uses the lightweight Chromium for AWS Lambda

export const handler = async () => {
  let browser;
  try {
    // Launch Puppeteer using the Chromium from the layer
    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(), // This gets the correct Chrome path from the layer
      headless: chromium.headless
    });

    const page = await browser.newPage();
    await page.goto('https://worldtabletennis.com/rankings', {
      waitUntil: 'networkidle2'
    });

    // Extract the desired HTML content
    const content = await page.evaluate(() => {
      const slides = Array.from(document.querySelectorAll('.slick-slide'));
      return slides.map(slide => {
        const cardHead = slide.querySelector('.card_head');
        return cardHead ? cardHead.textContent.trim() : null;
      }).filter(Boolean); // Remove any null values
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ content })
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  } finally {
    if (browser) {
      await browser.close();
    }
  }
};